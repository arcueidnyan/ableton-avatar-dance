Windows x64 VST3 instrument for MIDI tracks. Includes Blue Static and Kira. Extract the entire Avatar Dance.vst3 directory to the Windows system VST3 folder.

Windows binary cross-built and loaded under Wine. pluginval 0.3.0 strictness 5 passed, including editor tests. Transport, MIDI move changes, cycle sync, Held, graphics controls, state recall and custom sheets were also exercised in a processor smoke test. Ableton Live 12 itself has not been tested here.
